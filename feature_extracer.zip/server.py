#!/usr/bin/env python
# coding: utf-8

# pip install flask

import numpy as np
from PIL import Image
from datetime import datetime
from flask import Flask, request, render_template
from pathlib import Path
#get_ipython().run_line_magic('run', 'feature_extracer.ipynb import FeatureExtracter # Adding Jupyter Notebook file as class')
 
from feature_extracer import FeatureExtracter


app = Flask(__name__)

fe = FeatureExtracter()
feature = []
img_paths = []
for feature_path in Path("./assets/feature").glob("*.npy"):
    features.append(np.load(feature_path))
    img_paths.append(Path("./assets/img") / (feature_path.stem +  ".jpg"))
features = np.array(features)

@app.route("/", methods=["GET", "POST"])
def index():
    #return "Server is running!"
    #return render_template("index.html")
    if request.method == "POST":
        
        # Get image as file
        file = request.files["query_img"]
        #save query image
        img = Image.open(file.stream) # PIL image
        upload_img_path = "assets/upload/" + datetime.now().isoformat().replace(":", ".") + "_" +  file.filename
        img.save(upload_img_path)
        
        # Run our search 
        guery = fe.extract(img)
        dists = np.lingalg.norm(features - query, axis=1)
        ids = np.argsort(dists)[:30]
        scores = [(dists[id], img_paths[id]) for id in ids]
        
        print(scores)
        
        return render_template("index.html", query_path=upload_img_path)
    else:
        return render_template("index.html")

if __name__ == "__main__":
    app.run()

